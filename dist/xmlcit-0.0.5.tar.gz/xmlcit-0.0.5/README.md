# XMLCit package

## Purpose

## Structure
 
## Class description : Insert

### Method descriptions

     -  __ID__

     - __CitbyID__

     - __CitbyText__

## Additional Functions descriptions

 - __AddVIAF__

 - __Addtag__

 - __RepeatCitation__