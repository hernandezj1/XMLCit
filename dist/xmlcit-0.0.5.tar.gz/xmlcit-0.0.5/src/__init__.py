from .addtagfunc import Addtag
from .tagfunctions import Insert
from .opcit_functions import RepeatCitation
from .VIAF_functions import AddVIAF

