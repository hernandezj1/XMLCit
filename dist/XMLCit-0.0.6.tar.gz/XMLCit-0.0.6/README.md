# XMLCit package

## Purpose
 
  This packages was developed by staff of the Research Computing Center to serve the needs of our digital humanities community. Therefore the classes and functions in this package were develop with ease of use and to be applicable to TEI-XML standards. TEI-XML specifications can be found here <a href='https://tei-c.org/'>TEI</a>
## Structure
 
## Class description : Insert

  This class 

### Method descriptions

1.  __ID__

    

2.  __CitbyID__

3.  __CitbyText__

## Additional Functions descriptions

4.  __AddVIAF__

5.  __Addtag__

6. __RepeatCitation__
